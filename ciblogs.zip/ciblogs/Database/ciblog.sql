-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: May 06, 2019 at 11:44 AM
-- Server version: 5.7.21
-- PHP Version: 7.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ciblog`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
CREATE TABLE IF NOT EXISTS `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `created_at`) VALUES
(1, 'Business', '2018-09-26 03:00:51'),
(2, 'Technology', '2018-09-26 03:00:51'),
(3, 'Trending', '2018-09-26 14:48:51'),
(4, 'Prayer', '2018-09-26 17:54:34'),
(5, 'Blogging', '2018-09-27 04:50:43');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

DROP TABLE IF EXISTS `comments`;
CREATE TABLE IF NOT EXISTS `comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `post_id`, `name`, `email`, `body`, `created_at`) VALUES
(1, 10, 'Machindra', 'machindra@gmail.cm', 'this is my comment.', '2018-10-20 18:30:47'),
(2, 10, 'Jan Doe', 'jandoe@yahoo.com', 'thanks for the great post.', '2018-10-20 18:33:45');

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

DROP TABLE IF EXISTS `posts`;
CREATE TABLE IF NOT EXISTS `posts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `post_image` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `category_id`, `user_id`, `title`, `slug`, `body`, `post_image`, `created_at`) VALUES
(7, 2, 0, 'This Dumy Post', 'This-Dumy-Post', '<p>This Dumy PostThis Dumy PostThis Dumy PostThis Dumy PostThis Dumy Post.</p>', 'app-images.png', '2018-09-26 11:33:45'),
(8, 2, 0, 'Heading of this post is so so long  to view.', 'Heading-of-this-post-is-so-so-long-to-view', '<p>Heading of this post is so so long &nbsp;to view. Heading of this post is so so long &nbsp;to view.Heading of this post is so so long &nbsp;to view. Heading of this post is so so long &nbsp;to view. Heading of this post is so so long &nbsp;to view.</p><p><strong>Heading of this post is so so long &nbsp;to view.</strong></p><ul><li>THis is one line in post.</li><li>thisn is seconf line in post</li></ul><ol><li>Again poins added here.</li><li>second point is added here.</li></ol><p>&nbsp;</p><p>Heading of this post is so so long &nbsp;to view. Heading of this post is so so long &nbsp;to view. Heading of this post is so so long &nbsp;to view.</p><p>Heading of this post is so so long &nbsp;to view. Heading of this post is so so long &nbsp;to view. Heading of this post is so so long &nbsp;to view.</p>', 'app-images.png', '2018-09-26 11:36:26'),
(9, 2, 0, 'This Dumy Post', 'This-Dumy-Post', '<p>hfhfhjfh</p>', 'Noimage.jpg', '2018-09-26 11:39:45'),
(10, 1, 0, 'posts three is going here', 'posts-three-is-going-here', '<p>posts three is going here posts three is going here posts three is going here.</p>', 'loginlogo.png', '2018-09-26 11:48:48'),
(11, 5, 0, 'Testing post for check', 'Testing-post-for-check', '<p>Here is my post,</p>\r\n\r\n<hr />\r\n<p>I am writing this post only for the test purpose.</p>\r\n\r\n<table align=\"center\" border=\"1\" cellpadding=\"1\" cellspacing=\"1\" style=\"width:500px\" summary=\"For testing purpose only\">\r\n	<caption>Box</caption>\r\n	<thead>\r\n		<tr>\r\n			<th scope=\"col\">Line&nbsp; &nbsp; &nbsp; &nbsp;&nbsp;</th>\r\n			<th scope=\"col\">Lineeeeee</th>\r\n		</tr>\r\n	</thead>\r\n	<tbody>\r\n		<tr>\r\n			<td>&nbsp;</td>\r\n			<td>&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td>&nbsp;</td>\r\n			<td>&nbsp;</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>What is this for.</p>\r\n\r\n<p>How use this box.</p>\r\n\r\n<p><a id=\"Anchor Name\" name=\"Anchor Name\"></a>&nbsp; <em><strong>Anchor</strong></em><em><strong> is the post.</strong></em></p>\r\n\r\n<p><em><strong><s>how you do.</s></strong></em></p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<figure class=\"easyimage easyimage-side\"><img alt=\"Server Image\" src=\"blob:http://localhost/82807c1c-46ab-4a8e-8456-236e3a747324\" width=\"2000\" />\r\n<figcaption></figcaption>\r\n</figure>\r\n\r\n<p>&nbsp;</p>\r\n', '475503-PHQAE5-947.jpg', '2019-04-04 06:00:59'),
(12, 1, 0, 'this is only post', 'this-is-only-post', '<p><strong>this is only posted this is only posted this is only posted this is only posted this is only posted this is only posted this is the only post&nbsp;this is only post&nbsp;this is only post&nbsp;this is only post.</strong></p>\r\n\r\n<p>&nbsp;</p>\r\n', 'admin.png', '2019-05-04 06:44:18');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `zipcode` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `register_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `zipcode`, `email`, `username`, `password`, `register_date`) VALUES
(1, 'mahinder', '431001', 'mahin@gmail.com', 'machindra', '12345', '2018-09-30 03:21:59'),
(2, 'mahinder', '431001', 'mahin@gmail.com', 'machindra', '12345', '2018-09-30 03:26:58'),
(3, 'mahinder', '431001', 'mahin@gmail.com', 'machindra', '12345', '2018-09-30 03:30:14'),
(4, 'Om', '431001', 'ommohite@gmail.com', 'Om', 'Ommohite', '2018-10-20 18:47:18'),
(5, 'Amit', '431002', 'amit@yahoo.in', 'Amit', '827ccb0eea8a706c4c34a16891f84e7b', '2018-10-20 18:59:29');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
